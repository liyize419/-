package com.wakepc.woltv.net;

import android.content.Context;
import android.net.wifi.WifiManager;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.HashMap;
import java.util.Map;

public class MdnsDiscovery {
    private static final String GROUP = "224.0.0.251";
    private static final int PORT = 5353;
    private static final String[] QUERIES = {
            "_services._dns-sd._udp.local", "_device-info._tcp.local", "_smb._tcp.local",
            "_workstation._tcp.local", "_rfb._tcp.local", "_ssh._tcp.local",
            "_sftp-ssh._tcp.local", "_googlecast._tcp.local", "_googlezone._tcp.local",
            "_airplay._tcp.local", "_raop._tcp.local", "_appletv-v2._tcp.local",
            "_printer._tcp.local", "_ipp._tcp.local", "_ipps._tcp.local",
            "_pdl-datastream._tcp.local", "_hap._tcp.local", "_androidtvremote._tcp.local",
            "_androidtv._tcp.local", "_roku._tcp.local", "_spotify-connect._tcp.local",
            "_sonos._tcp.local", "_media-player-tls._tcp.local"};

    public static class Tags {
        public boolean airplay;
        public boolean cast;
        public boolean homekit;
        public boolean mac;
        public String model;
        public String serviceHostname;
        public boolean printer;
        public boolean smbSvc;
        public boolean sshSvc;
        public boolean tv;
        public boolean vnc;
        public boolean workstation;

        public boolean computerSignal() {
            return mac || smbSvc || workstation || vnc || sshSvc;
        }

        public boolean excluded() {
            return cast || airplay || printer || homekit || tv;
        }
    }

    public Map<String, Tags> discover(Context context, long durationMs) {
        Map<String, Tags> result = new HashMap<>();
        WifiManager.MulticastLock lock = null;
        MulticastSocket socket = null;
        try {
            WifiManager wm = (WifiManager) context.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                lock = wm.createMulticastLock("wol:mdns");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
            InetAddress group = InetAddress.getByName(GROUP);
            socket = new MulticastSocket();
            socket.setSoTimeout(1500);
            socket.setTimeToLive(255);
            socket.joinGroup(group);

            byte[] query = buildQuery();
            socket.send(new DatagramPacket(query, query.length, group, PORT));

            long deadline = System.currentTimeMillis() + durationMs;
            byte[] buf = new byte[4096];
            while (System.currentTimeMillis() < deadline) {
                try {
                    DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                    socket.receive(pkt);
                    byte[] copy = new byte[pkt.getLength()];
                    System.arraycopy(pkt.getData(), 0, copy, 0, pkt.getLength());
                    String src = pkt.getAddress().getHostAddress();
                    int pct = src.indexOf('%');
                    if (pct >= 0) {
                        src = src.substring(0, pct);
                    }
                    Tags tags = result.get(src);
                    if (tags == null) {
                        tags = new Tags();
                        result.put(src, tags);
                    }
                    parsePacket(copy, tags);
                } catch (java.net.SocketTimeoutException ste) {
                    // 继续等
                }
            }
        } catch (Exception e) {
            return result;
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (Exception ignored) {
                }
            }
            if (lock != null && lock.isHeld()) {
                lock.release();
            }
        }
        return result;
    }

    private static byte[] buildQuery() {
        int n = QUERIES.length;
        byte[][] names = new byte[n][];
        int total = 0;
        for (int i = 0; i < n; i++) {
            names[i] = encodeName(QUERIES[i]);
            total += names[i].length + 4;
        }
        byte[] out = new byte[total + 12];
        out[5] = (byte) n;
        int pos = 12;
        for (int i = 0; i < n; i++) {
            System.arraycopy(names[i], 0, out, pos, names[i].length);
            int after = pos + names[i].length;
            out[after + 1] = 0x00;
            out[after + 3] = 0x01;
            pos = after + 4;
        }
        return out;
    }

    private static byte[] encodeName(String name) {
        String[] parts = name.split("\\.");
        int len = 1;
        for (String p : parts) {
            len += p.length() + 1;
        }
        byte[] out = new byte[len];
        int pos = 0;
        for (String p : parts) {
            byte[] pb = p.getBytes();
            out[pos++] = (byte) pb.length;
            System.arraycopy(pb, 0, out, pos, pb.length);
            pos += pb.length;
        }
        out[pos] = 0;
        return out;
    }

    private static void parsePacket(byte[] b, Tags tags) {
        try {
            int qd = u16(b, 4);
            int an = u16(b, 6);
            int ns = u16(b, 8);
            int ar = u16(b, 10);
            int pos = 12;
            for (int i = 0; i < qd; i++) {
                pos = skipName(b, pos) + 4;
            }
            int records = an + ns + ar;
            for (int i = 0; i < records; i++) {
                if (pos + 12 > b.length) {
                    return;
                }
                String name = nameString(b, pos);
                int[] rn = readName(b, pos);
                int dataPos = rn[1];
                int type = u16(b, dataPos);
                int rdLen = u16(b, dataPos + 8);
                int rdStart = dataPos + 10;
                if (rdStart + rdLen > b.length) {
                    return;
                }
                String lower = name.toLowerCase();
                if (type == 12) {
                    classify(lower, tags);
                } else if (type == 16 && lower.contains("_device-info")) {
                    String txt = readTxt(b, rdStart, rdLen);
                    tags.mac = true;
                    int idx = txt.toLowerCase().indexOf("model=");
                    if (idx >= 0) {
                        String model = txt.substring(idx + 6).split("\"|'|\n")[0].trim();
                        tags.model = model;
                        String ml = model.toLowerCase();
                        if (!ml.contains("mac") && !ml.startsWith("imac")) {
                            tags.mac = false;
                        }
                    }
                }
                pos = rdStart + rdLen;
            }
        } catch (Exception ignored) {
        }
    }

    private static void classify(String name, Tags tags) {
        if (name.contains("_device-info")) {
            tags.mac = true;
            takeHostname(name, tags);
        } else if (name.contains("_smb._tcp")) {
            tags.smbSvc = true;
            takeHostname(name, tags);
        } else if (name.contains("_workstation")) {
            tags.workstation = true;
            takeHostname(name, tags);
        } else if (name.contains("_rfb._tcp")) {
            tags.vnc = true;
            takeHostname(name, tags);
        } else if (name.contains("_ssh._tcp") || name.contains("_sftp-ssh")) {
            tags.sshSvc = true;
            takeHostname(name, tags);
        } else if (name.contains("_googlecast") || name.contains("_googlezone")
                || name.contains("_spotify") || name.contains("_sonos")
                || name.contains("_media-player")) {
            tags.cast = true;
        } else if (name.contains("_airplay") || name.contains("_raop")
                || name.contains("_appletv")) {
            tags.airplay = true;
        } else if (name.contains("_printer") || name.contains("_ipp")
                || name.contains("_pdl-datastream")) {
            tags.printer = true;
        } else if (name.contains("_hap.")) {
            tags.homekit = true;
        } else if (name.contains("_androidtv") || name.contains("_roku")) {
            tags.tv = true;
        }
    }

    /** 从服务实例名首标签提取主机名（如 DESKTOP-A1._smb._tcp.local -> DESKTOP-A1） */
    private static void takeHostname(String name, Tags tags) {
        if (tags.serviceHostname != null) {
            return;
        }
        int dot = name.indexOf('.');
        String first = dot > 0 ? name.substring(0, dot) : name;
        first = first.replaceAll("[\\\\%\\s]+", " ").trim();
        if (first.length() >= 2 && !first.startsWith("_")) {
            tags.serviceHostname = first;
        }
    }

    private static String readTxt(byte[] b, int pos, int len) {
        StringBuilder sb = new StringBuilder();
        int end = pos + len;
        while (pos < end) {
            int l = b[pos] & 255;
            if (pos + 1 + l > end) {
                break;
            }
            sb.append(new String(b, pos + 1, l)).append('\n');
            pos += 1 + l;
        }
        return sb.toString();
    }

    private static int[] readName(byte[] b, int pos) {
        StringBuilder sb = new StringBuilder();
        int after = pos;
        boolean compressed = false;
        int hops = 0;
        while (pos < b.length) {
            int l = b[pos] & 255;
            if (l == 0) {
                pos++;
                break;
            }
            if ((l & 192) == 192) {
                if (!compressed) {
                    after = pos + 2;
                }
                pos = (b[pos + 1] & 255) | ((l & 63) << 8);
                compressed = true;
                if (++hops > 8) {
                    break;
                }
            } else {
                if (sb.length() > 0) {
                    sb.append('.');
                }
                sb.append(new String(b, pos + 1, l));
                pos += l + 1;
            }
        }
        if (compressed) {
            pos = after;
        }
        return new int[]{0, pos, 0};
    }

    private static String nameString(byte[] b, int pos) {
        StringBuilder sb = new StringBuilder();
        int hops = 0;
        while (pos < b.length) {
            int l = b[pos] & 255;
            if (l == 0) {
                break;
            }
            if ((l & 192) == 192) {
                pos = (b[pos + 1] & 255) | ((l & 63) << 8);
                if (++hops > 8) {
                    break;
                }
            } else {
                if (sb.length() > 0) {
                    sb.append('.');
                }
                sb.append(new String(b, pos + 1, l));
                pos += l + 1;
            }
        }
        return sb.toString();
    }

    private static int skipName(byte[] b, int pos) {
        int hops = 0;
        while (pos < b.length) {
            int l = b[pos] & 255;
            if (l == 0) {
                return pos + 1;
            }
            if ((l & 192) == 192) {
                return pos + 2;
            }
            pos += l + 1;
            if (++hops > 64) {
                break;
            }
        }
        return pos;
    }

    private static int u16(byte[] b, int pos) {
        return ((b[pos] & 255) << 8) | (b[pos + 1] & 255);
    }
}
