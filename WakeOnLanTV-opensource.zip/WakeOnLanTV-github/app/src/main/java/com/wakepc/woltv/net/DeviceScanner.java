package com.wakepc.woltv.net;

import android.content.Context;

import com.wakepc.woltv.model.Device;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class DeviceScanner {

    public interface Callback {
        void onProgress(int done, int total);

        void onHostAlive(String ip);

        void onComplete(List<Device> devices, List<NetInfo> nets);

        void onError(String msg);
    }

    /** 快速扫描结果：规范化 MAC(小写) -> 当前 IP */
    public interface QuickCallback {
        void onProgress(int done, int total);

        void onComplete(Map<String, String> macToIp);

        void onError(String msg);
    }

    private volatile boolean canceled = false;
    private final Context appCtx;

    public DeviceScanner(Context context) {
        appCtx = context.getApplicationContext();
    }

    public void cancel() {
        canceled = true;
    }

    public void scan(final Callback cb) {
        ExecutorService pool = Executors.newFixedThreadPool(128, new ThreadFactory() {
            private final AtomicInteger n = new AtomicInteger();

            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "scan-" + n.incrementAndGet());
                t.setDaemon(true);
                return t;
            }
        });
        try {
            final List<NetInfo> nets = NetInfo.enumerate();
            if (nets.isEmpty()) {
                cb.onError("未连接局域网，请检查网络");
                return;
            }

            // mDNS 并发发现
            long mdnsStart = System.currentTimeMillis();
            final AtomicReference<Map<String, MdnsDiscovery.Tags>> mdnsRef =
                    new AtomicReference<Map<String, MdnsDiscovery.Tags>>();
            Thread mdnsThread = new Thread(new Runnable() {
                public void run() {
                    mdnsRef.set(new MdnsDiscovery().discover(appCtx, 7000L));
                }
            }, "mdns");
            mdnsThread.setDaemon(true);
            mdnsThread.start();

            // SSDP / UPnP 并发发现（取设备名）
            long ssdpStart = System.currentTimeMillis();
            final AtomicReference<Map<String, String>> ssdpRef =
                    new AtomicReference<Map<String, String>>();
            Thread ssdpThread = new Thread(new Runnable() {
                public void run() {
                    ssdpRef.set(new SsdpDiscovery().discover(4000L));
                }
            }, "ssdp");
            ssdpThread.setDaemon(true);
            ssdpThread.start();

            // 收集待扫描 IP
            List<byte[]> hosts = new ArrayList<byte[]>();
            for (NetInfo ni : nets) {
                hosts.addAll(ni.hostsToScan());
            }
            final int total = hosts.size();
            final AtomicInteger done = new AtomicInteger(0);
            ExecutorCompletionService<String> ecs = new ExecutorCompletionService<String>(pool);
            List<Future<String>> futures = new ArrayList<Future<String>>();

            for (byte[] ipBytes : hosts) {
                final String ip = NetInfo.formatIp(ipBytes);
                futures.add(ecs.submit(new Callable<String>() {
                    public String call() {
                        if (canceled) {
                            return null;
                        }
                        int ttl = Pinger.aliveTtl(ip);
                        cb.onProgress(done.incrementAndGet(), total);
                        if (ttl < 0) {
                            return null;
                        }
                        return ip + "," + ttl;
                    }
                }));
            }

            List<String[]> alive = new ArrayList<String[]>();
            for (int i = 0; i < futures.size(); i++) {
                try {
                    String r = ecs.take().get();
                    if (r != null) {
                        String[] c = r.split(",");
                        String ttl = c.length > 1 ? c[1] : "0";
                        alive.add(new String[]{c[0], ttl});
                        cb.onHostAlive(c[0]);
                    }
                } catch (Exception ignored) {
                }
                if (canceled) {
                    break;
                }
            }
            if (canceled) {
                cb.onComplete(new ArrayList<Device>(), nets);
                return;
            }

            // ARP：两次读取合并，尽量等齐 ping 产生的缓存
            Map<String, String> arp = ArpTable.snapshot();
            try {
                Thread.sleep(400);
            } catch (InterruptedException ignored) {
            }
            for (Map.Entry<String, String> e : ArpTable.snapshot().entrySet()) {
                if (!arp.containsKey(e.getKey())) {
                    arp.put(e.getKey(), e.getValue());
                }
            }

            // 对存活主机做信息补全
            final List<Device> devices = new ArrayList<Device>();
            final Object lock = new Object();
            List<Future<?>> enrich = new ArrayList<Future<?>>();
            for (final String[] a : alive) {
                enrich.add(pool.submit(new Runnable() {
                    public void run() {
                        String ip = a[0];
                        int ttl;
                        try {
                            ttl = Integer.parseInt(a[1]);
                        } catch (Exception e) {
                            ttl = -1;
                        }
                        Device d = new Device();
                        d.ip = ip;
                        d.mac = arp.get(ip);
                        d.ttl = ttl;
                        d.lastSeen = System.currentTimeMillis();

                        String name = NetBiosName.query(ip, 1500);
                        if (name != null && !name.isEmpty()) {
                            d.hostname = name;
                        }
                        PortProbe.Result pr = PortProbe.probe(ip);
                        d.smb = pr.smb;
                        d.rdp = pr.rdp;
                        d.ssh = pr.ssh;
                        if ((d.hostname == null || d.hostname.isEmpty()) && pr.reverseName != null) {
                            d.hostname = pr.reverseName;
                        }
                        d.applyOui();

                        int ipInt = NetInfo.toInt(parseIp(ip));
                        for (NetInfo ni : nets) {
                            if ((NetInfo.toInt(ni.mask) & ipInt)
                                    == (NetInfo.toInt(ni.ip) & NetInfo.toInt(ni.mask))) {
                                d.broadcast = ni.broadcastString();
                                break;
                            }
                        }
                        synchronized (lock) {
                            devices.add(d);
                        }
                    }
                }));
            }
            for (Future<?> f : enrich) {
                try {
                    f.get();
                } catch (Exception ignored) {
                }
            }

            // 动态等待：保证覆盖发现线程的完整周期，避免结果因提前超时而丢失
            long mdnsWait = (mdnsStart + 7500L) - System.currentTimeMillis();
            try {
                mdnsThread.join(Math.max(500L, Math.min(mdnsWait, 9000L)));
            } catch (Exception ignored) {
            }
            Map<String, MdnsDiscovery.Tags> mdns = mdnsRef.get();
            if (mdns == null) {
                mdns = new java.util.HashMap<String, MdnsDiscovery.Tags>();
            }

            long ssdpWait = (ssdpStart + 11500L) - System.currentTimeMillis();
            try {
                ssdpThread.join(Math.max(500L, Math.min(ssdpWait, 13000L)));
            } catch (Exception ignored) {
            }
            Map<String, String> ssdp = ssdpRef.get();
            if (ssdp == null) {
                ssdp = new java.util.HashMap<String, String>();
            }

            String gateway = NetInfo.defaultGateway();
            List<Device> computers = new ArrayList<Device>();
            for (Device d : devices) {
                boolean isGw = d.ip.equals(gateway);
                if (!isGw) {
                    int ipInt = NetInfo.toInt(parseIp(d.ip));
                    for (NetInfo ni : nets) {
                        int netInt = NetInfo.toInt(ni.ip) & NetInfo.toInt(ni.mask);
                        if ((NetInfo.toInt(ni.mask) & ipInt) == netInt && ipInt == netInt + 1) {
                            isGw = true;
                            break;
                        }
                    }
                }
                if (isGw) {
                    // 过滤路由器 / 网关
                    continue;
                }

                MdnsDiscovery.Tags tags = mdns.get(d.ip);

                // 主机名补全：SSDP 设备名 -> mDNS 服务实例名 -> Mac 型号
                if (d.hostname == null || d.hostname.isEmpty()) {
                    String ssdpName = ssdp.get(d.ip);
                    if (ssdpName != null && !ssdpName.isEmpty()) {
                        d.hostname = ssdpName;
                    } else if (tags != null) {
                        if (tags.serviceHostname != null && !tags.serviceHostname.isEmpty()) {
                            d.hostname = tags.serviceHostname;
                        } else if (tags.model != null
                                && tags.model.toLowerCase().contains("mac")) {
                            d.hostname = tags.model;
                        }
                    }
                }

                // 只保留电脑（含虚拟机）
                boolean isPc = DeviceClassifier.isComputer(d, tags) || d.virtual;
                if (isPc) {
                    computers.add(d);
                }
            }
            cb.onComplete(computers, nets);
        } catch (Exception e) {
            cb.onError("扫描失败：" + e.getMessage());
        } finally {
            pool.shutdownNow();
        }
    }

    /**
     * 快速扫描：高并发 ping 整个网段触发 ARP，再读 ARP 表反查 MAC->IP。
     * 不做主机名/端口探测，约 2 秒完成，用于启动状态检测与唤醒前定位。
     */
    public void quickScan(final QuickCallback cb) {
        ExecutorService pool = Executors.newFixedThreadPool(180, new ThreadFactory() {
            private final AtomicInteger n = new AtomicInteger();

            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "qscan-" + n.incrementAndGet());
                t.setDaemon(true);
                return t;
            }
        });
        try {
            List<NetInfo> nets = NetInfo.enumerate();
            if (nets.isEmpty()) {
                cb.onError("未连接局域网，请检查网络");
                return;
            }

            List<byte[]> hosts = new ArrayList<byte[]>();
            for (NetInfo ni : nets) {
                hosts.addAll(ni.hostsToScan());
            }
            final int total = hosts.size();
            final AtomicInteger done = new AtomicInteger(0);
            // 记录本轮实测可达的 IP，ARP 残留的关机设备不得计入
            final java.util.Set<String> aliveIps = java.util.Collections.newSetFromMap(
                    new java.util.concurrent.ConcurrentHashMap<String, Boolean>());
            ExecutorCompletionService<Integer> ecs =
                    new ExecutorCompletionService<Integer>(pool);
            List<Future<Integer>> futures = new ArrayList<Future<Integer>>();

            for (byte[] ipBytes : hosts) {
                final String ip = NetInfo.formatIp(ipBytes);
                futures.add(ecs.submit(new Callable<Integer>() {
                    public Integer call() {
                        int ttl = canceled ? -1 : Pinger.aliveTtl(ip);
                        if (ttl >= 0) {
                            aliveIps.add(ip);
                        }
                        cb.onProgress(done.incrementAndGet(), total);
                        return ttl;
                    }
                }));
            }
            for (int i = 0; i < futures.size(); i++) {
                try {
                    ecs.take().get();
                } catch (Exception ignored) {
                }
                if (canceled) {
                    break;
                }
            }

            // ARP 两次快照合并（ping 刚触发，间隔短）
            Map<String, String> arp = ArpTable.snapshot();
            try {
                Thread.sleep(250);
            } catch (InterruptedException ignored) {
            }
            for (Map.Entry<String, String> e : ArpTable.snapshot().entrySet()) {
                if (!arp.containsKey(e.getKey())) {
                    arp.put(e.getKey(), e.getValue());
                }
            }

            // 反查 MAC -> IP（仅保留本轮实测可达的设备）
            Map<String, String> macToIp = new java.util.HashMap<String, String>();
            for (Map.Entry<String, String> e : arp.entrySet()) {
                if (!aliveIps.contains(e.getKey())) {
                    continue;
                }
                String m = e.getValue() == null ? "" : e.getValue().toLowerCase();
                if (m.matches("([0-9a-f]{2}:){5}[0-9a-f]{2}")
                        && !macToIp.containsKey(m)) {
                    macToIp.put(m, e.getKey());
                }
            }
            cb.onComplete(macToIp);
        } catch (Exception e) {
            cb.onError("扫描失败：" + e.getMessage());
        } finally {
            pool.shutdownNow();
        }
    }

    /**
     * 快速验证「上次绑定的 IP」是否仍是目标设备：
     * 必须先确认设备当前可达（ping，ICMP 被禁时用 SMB/RDP 端口兜底），再核对 ARP 表中的 MAC。
     * 关机后 ARP 缓存会残留旧条目，因此 ping 不通一律判离线；可达且 MAC 对得上才返回 true。
     */
    public static boolean checkCachedIp(String ip, String mac) {
        if (ip == null || ip.isEmpty() || mac == null || mac.isEmpty()) {
            return false;
        }
        boolean reachable = Pinger.pingOnce(ip, 1);
        if (!reachable) {
            reachable = Pinger.tcpCheck(ip, PortProbe.PORT_SMB, 500)
                    || Pinger.tcpCheck(ip, PortProbe.PORT_RDP, 500);
        }
        if (!reachable) {
            return false;
        }
        Map<String, String> arp = ArpTable.snapshot();
        String real = arp == null ? null : arp.get(ip);
        if (real == null) {
            try {
                Thread.sleep(180);
            } catch (InterruptedException ignored) {
            }
            arp = ArpTable.snapshot();
            real = arp == null ? null : arp.get(ip);
        }
        return real != null && real.equalsIgnoreCase(mac);
    }

    public static byte[] parseIp(String ip) {
        String[] p = ip.split("\\.");
        byte[] out = new byte[4];
        for (int i = 0; i < 4; i++) {
            out[i] = (byte) Integer.parseInt(p[i]);
        }
        return out;
    }
}
