package com.wakepc.woltv.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.wakepc.woltv.model.AppConfig;

import org.json.JSONObject;

public class ConfigStore {
    private static final String PREF = "woltv_config";
    private static final String KEY_CONFIGURED = "configured";
    private static final String KEY_CONFIG = "config_json";

    private final SharedPreferences sp;

    public ConfigStore(Context context) {
        sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public boolean isConfigured() {
        return sp.getBoolean(KEY_CONFIGURED, false);
    }

    public AppConfig load() {
        try {
            String json = sp.getString(KEY_CONFIG, null);
            if (json == null || json.isEmpty()) {
                return null;
            }
            return AppConfig.fromJson(new JSONObject(json));
        } catch (Exception e) {
            return null;
        }
    }

    public void save(AppConfig config) {
        try {
            sp.edit()
                    .putString(KEY_CONFIG, config.toJson().toString())
                    .putBoolean(KEY_CONFIGURED, true)
                    .apply();
        } catch (Exception ignored) {
        }
    }

    public void reset() {
        sp.edit().clear().apply();
    }
}
