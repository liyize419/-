package com.wakepc.woltv.net;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class NetBiosName {

    /** 向目标 UDP 137 发送 NetBIOS 节点状态查询，返回计算机名；失败返回 null */
    public static String query(String ip, int timeoutMs) {
        DatagramSocket s = null;
        try {
            byte[] req = buildRequest();
            s = new DatagramSocket();
            s.setSoTimeout(timeoutMs);
            s.send(new DatagramPacket(req, req.length, InetAddress.getByName(ip), 137));
            byte[] buf = new byte[1024];
            DatagramPacket resp = new DatagramPacket(buf, buf.length);
            s.receive(resp);
            return parseResponse(buf, resp.getLength());
        } catch (Exception e) {
            return null;
        } finally {
            if (s != null) {
                s.close();
            }
        }
    }

    private static byte[] buildRequest() {
        byte[] b = new byte[50];
        b[1] = 0x2a; // 事务 ID 低字节
        b[5] = 0x01; // 问题数
        b[12] = 0x20;
        for (int i = 0; i < 32; i++) {
            b[i + 13] = 0x41; // 通配名 '*'
        }
        b[45] = 0x00;
        b[47] = 0x21; // NBSTAT
        b[49] = 0x01; // 广播
        return b;
    }

    private static String parseResponse(byte[] b, int len) {
        try {
            int qd = ((b[4] & 255) << 8) | (b[5] & 255);
            int pos = 12;
            for (int i = 0; i < qd; i++) {
                pos = skipName(b, pos) + 4;
            }
            int afterName = ((b[pos] & 192) == 192) ? pos + 2 : skipName(b, pos);
            // afterName 起：TYPE(2) CLASS(2) TTL(4) RDLENGTH(2) RDATA...
            int rdLenPos = afterName + 8;
            int rrLen = ((b[rdLenPos] & 255) << 8) | (b[rdLenPos + 1] & 255);
            int p = rdLenPos + 2; // RDATA 起点：首字节为名称数量 NUM_NAMES
            if (p + 1 > len) {
                return null;
            }
            int count = b[p] & 255;
            p += 1;
            String name = null;
            for (int i = 0; i < count; i++) {
                if (p + 18 > len) {
                    break;
                }
                String candidate = new String(b, p, 16, "ISO-8859-1").trim();
                int flags = (((b[p + 16] & 255) << 8) | (b[p + 17] & 255)) & 255;
                if (!candidate.isEmpty() && flags == 0 && name == null) {
                    name = candidate;
                }
                p += 18;
            }
            return name;
        } catch (Exception e) {
            return null;
        }
    }

    private static int skipName(byte[] b, int pos) {
        while (pos < b.length) {
            int l = b[pos] & 255;
            if (l == 0) {
                return pos + 1;
            }
            if ((l & 192) == 192) {
                return pos + 2;
            }
            pos += l + 1;
        }
        return pos;
    }
}
