package com.wakepc.woltv.net;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class WakeOnLan {

    /**
     * 发送魔术包：端口 9 与 7，全网广播 255.255.255.255；
     * 若提供子网定向广播地址则一并发送。重复 rounds 轮，间隔 800ms。
     */
    public static void send(String mac, String directedBroadcast, int rounds) {
        byte[] packet = buildPacket(mac);
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket();
            socket.setBroadcast(true);
            InetAddress all = InetAddress.getByName("255.255.255.255");
            InetAddress directed = null;
            if (directedBroadcast != null && !directedBroadcast.isEmpty()
                    && !directedBroadcast.equals("255.255.255.255")) {
                directed = InetAddress.getByName(directedBroadcast);
            }
            for (int i = 0; i < rounds; i++) {
                sendOne(socket, packet, all, 9);
                sendOne(socket, packet, all, 7);
                if (directed != null) {
                    sendOne(socket, packet, directed, 9);
                    sendOne(socket, packet, directed, 7);
                }
                if (i < rounds - 1) {
                    Thread.sleep(800);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("魔术包发送失败: " + e.getMessage(), e);
        } finally {
            if (socket != null) {
                socket.close();
            }
        }
    }

    private static void sendOne(DatagramSocket s, byte[] data, InetAddress to, int port) {
        try {
            s.send(new DatagramPacket(data, data.length, to, port));
        } catch (Exception ignored) {
        }
    }

    /** 标准魔术包：6 字节 0xFF 后接 16 次目标 MAC，共 102 字节 */
    public static byte[] buildPacket(String mac) {
        byte[] macBytes = parseMacBytes(mac);
        byte[] packet = new byte[102];
        for (int i = 0; i < 6; i++) {
            packet[i] = (byte) 0xFF;
        }
        for (int i = 0; i < 16; i++) {
            System.arraycopy(macBytes, 0, packet, i * 6 + 6, 6);
        }
        return packet;
    }

    private static byte[] parseMacBytes(String mac) {
        String hex = mac.toLowerCase().replaceAll("[^0-9a-f]", "");
        byte[] out = new byte[6];
        for (int i = 0; i < 6; i++) {
            out[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
        }
        return out;
    }
}
