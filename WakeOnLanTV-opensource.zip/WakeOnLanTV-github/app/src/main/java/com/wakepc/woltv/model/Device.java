package com.wakepc.woltv.model;

import com.wakepc.woltv.net.Oui;

public class Device {
    public String ip;
    public String mac;
    public String hostname;
    public String broadcast;
    public String vendor;
    public int ttl = -1;
    public long lastSeen;
    public boolean smb;
    public boolean rdp;
    public boolean ssh;
    public boolean gateway;
    public boolean virtual;

    public String displayName() {
        if (hostname != null && !hostname.isEmpty()) {
            return hostname;
        }
        if (vendor != null && !vendor.isEmpty()) {
            return vendor + " 设备";
        }
        String tail = macTail();
        if (!tail.isEmpty()) {
            return "未知设备 " + tail;
        }
        return "未知电脑";
    }

    /** 取 MAC 后两位字节（4 位 HEX）用于区分同名未知设备，绝不回退到 IP */
    private String macTail() {
        if (mac == null) {
            return "";
        }
        String hex = mac.replaceAll("[^0-9a-fA-F]", "");
        if (hex.length() < 4) {
            return "";
        }
        return hex.substring(hex.length() - 4).toUpperCase();
    }

    public static String normalizeMac(String in) {
        if (in == null) {
            return null;
        }
        String hex = in.trim().toLowerCase().replaceAll("[^0-9a-f]", "");
        if (hex.length() != 12) {
            return null;
        }
        StringBuilder sb = new StringBuilder(17);
        for (int i = 0; i < 6; i++) {
            if (i > 0) {
                sb.append(':');
            }
            sb.append(hex, i * 2, i * 2 + 2);
        }
        return sb.toString();
    }

    public void applyOui() {
        if (mac == null) {
            return;
        }
        Oui.Info info = Oui.lookup(mac);
        if (info != null) {
            vendor = info.vendor;
            virtual = info.virtualMachine;
        }
    }
}
