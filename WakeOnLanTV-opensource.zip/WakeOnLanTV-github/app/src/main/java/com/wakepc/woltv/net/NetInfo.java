package com.wakepc.woltv.net;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public class NetInfo {
    public final String name;
    public final byte[] ip;
    public final short prefix;
    public final byte[] broadcast;
    public final byte[] mask;

    private NetInfo(String name, byte[] ip, short prefix, byte[] broadcast, byte[] mask) {
        this.name = name;
        this.ip = ip;
        this.prefix = prefix;
        this.broadcast = broadcast;
        this.mask = mask;
    }

    public String ipString() {
        return formatIp(ip);
    }

    public String broadcastString() {
        return formatIp(broadcast);
    }

    public static String formatIp(byte[] b) {
        return (b[0] & 255) + "." + (b[1] & 255) + "." + (b[2] & 255) + "." + (b[3] & 255);
    }

    public static List<NetInfo> enumerate() {
        List<NetInfo> result = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            List<NetworkInterface> list = Collections.list(ifaces);
            for (NetworkInterface ni : list) {
                try {
                    if (!ni.isUp() || ni.isLoopback()) {
                        continue;
                    }
                    for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                        if (ia.getAddress().getAddress().length != 4) {
                            continue; // 只要 IPv4
                        }
                        byte[] ip = ia.getAddress().getAddress();
                        short prefix = ia.getNetworkPrefixLength();
                        if (prefix <= 0 || prefix > 32) {
                            prefix = 24;
                        }
                        byte[] mask = prefixToMask(prefix);
                        byte[] bc = ia.getBroadcast() != null
                                ? ia.getBroadcast().getAddress()
                                : computeBroadcast(ip, mask);
                        result.add(new NetInfo(ni.getName(), ip, prefix, bc, mask));
                    }
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
        return result;
    }

    /** 解析 /proc/net/route，返回默认网关 IP（形如 192.168.1.1），无则 null */
    public static String defaultGateway() {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("/proc/net/route"));
            String line;
            br.readLine(); // 表头
            while ((line = br.readLine()) != null) {
                String[] c = line.trim().split("\\s+");
                if (c.length >= 3 && "00000000".equalsIgnoreCase(c[1])) {
                    byte[] raw = hexLittleEndian(c[2]);
                    if (raw != null) {
                        return formatIp(raw);
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Exception ignored) {
                }
            }
        }
        return null;
    }

    /** /proc/net/route 中地址为小端十六进制，如 0101A8C0 -> [C0,A8,01,01] */
    private static byte[] hexLittleEndian(String hex) {
        try {
            if (hex.length() != 8) {
                return null;
            }
            byte[] out = new byte[4];
            for (int i = 0; i < 4; i++) {
                int pos = (3 - i) * 2;
                out[i] = (byte) Integer.parseInt(hex.substring(pos, pos + 2), 16);
            }
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    public static byte[] prefixToMask(short prefix) {
        byte[] mask = new byte[4];
        int bits = prefix;
        for (int i = 0; i < 4; i++) {
            int take = Math.min(8, bits);
            mask[i] = (byte) (take == 0 ? 0 : (255 << (8 - take)) & 255);
            bits -= take;
        }
        return mask;
    }

    public static byte[] computeBroadcast(byte[] ip, byte[] mask) {
        byte[] bc = new byte[4];
        for (int i = 0; i < 4; i++) {
            bc[i] = (byte) ((ip[i] & mask[i]) | ((mask[i] ^ -1) & 255));
        }
        return bc;
    }

    public List<byte[]> hostsToScan() {
        short pf = prefix;
        byte[] useMask = mask;
        byte[] useBc = broadcast;
        if (32 - pf > 8) {
            useMask = prefixToMask((short) 24);
            useBc = computeBroadcast(ip, useMask);
        }
        int net = toInt(ip) & toInt(useMask);
        int end = toInt(useBc);
        int self = toInt(ip);
        List<byte[]> hosts = new ArrayList<>();
        int cur = net;
        while (true) {
            cur++;
            if (cur >= end) {
                return hosts;
            }
            if (cur != self) {
                hosts.add(toBytes(cur));
            }
        }
    }

    public static byte[] toBytes(int v) {
        return new byte[]{(byte) (v >>> 24), (byte) (v >>> 16), (byte) (v >>> 8), (byte) v};
    }

    public static int toInt(byte[] b) {
        return ((b[0] & 255) << 24) | ((b[1] & 255) << 16) | ((b[2] & 255) << 8) | (b[3] & 255);
    }
}
