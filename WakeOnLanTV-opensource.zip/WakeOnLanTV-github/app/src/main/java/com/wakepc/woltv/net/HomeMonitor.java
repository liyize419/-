package com.wakepc.woltv.net;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import com.wakepc.woltv.data.ConfigStore;
import com.wakepc.woltv.model.AppConfig;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 主页设备在线状态「实时」监控：
 * 每隔 {@link #INTERVAL_MS} 对当前 IP 做轻量可达检测（ping，ICMP 被禁用 SMB/RDP 兜底）；
 * 单次失败容忍（防丢包抖动），连续失败才按 MAC 做一次全网快速定位（处理 IP 变化），定位不到判离线。
 * 全部回调在主线程。
 */
public class HomeMonitor {

    public interface StateCallback {
        /** slot：1=主设备(单机PC/虚拟机宿主机)，2=被控虚拟机；state：1=在线，2=离线 */
        void onState(int slot, int state);

        /** 定位到新 IP 并已保存后回调，可用于刷新名称等 */
        void onConfigChanged();
    }

    public static final int ONLINE = 1;
    public static final int OFFLINE = 2;

    private static final long INTERVAL_MS = 5000;
    private static final long RESCAN_THROTTLE_MS = 15000;
    private static final int FAIL_THRESHOLD = 2;

    private final Context appCtx;
    private final ConfigStore store;
    private final StateCallback callback;
    private final Handler main = new Handler(Looper.getMainLooper());

    private ScheduledExecutorService exec;
    private DeviceScanner scanner;
    private volatile boolean running;
    private long lastFullScan;
    private int fail1 = 1;
    private int fail2 = 1;
    private int state1 = -1;
    private int state2 = -1;

    public HomeMonitor(Context context, ConfigStore store, StateCallback cb) {
        this.appCtx = context.getApplicationContext();
        this.store = store;
        this.callback = cb;
    }

    public void start() {
        if (running) {
            return;
        }
        running = true;
        lastFullScan = 0;
        fail1 = 1;
        fail2 = 1;
        state1 = -1;
        state2 = -1;
        exec = Executors.newSingleThreadScheduledExecutor();
        exec.scheduleWithFixedDelay(new Runnable() {
            public void run() {
                if (running) {
                    tick();
                }
            }
        }, 0, INTERVAL_MS, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        running = false;
        if (exec != null) {
            exec.shutdownNow();
        }
        if (scanner != null) {
            scanner.cancel();
        }
    }

    private boolean reachable(String ip) {
        if (ip == null || ip.isEmpty()) {
            return false;
        }
        if (Pinger.pingOnce(ip, 1)) {
            return true;
        }
        return Pinger.tcpCheck(ip, PortProbe.PORT_SMB, 500)
                || Pinger.tcpCheck(ip, PortProbe.PORT_RDP, 500);
    }

    private void tick() {
        final AppConfig c = store.load();
        if (c == null) {
            return;
        }
        final boolean vm = c.mode == AppConfig.MODE_VM;

        // 1. 轻量检测当前 IP
        boolean r1 = c.mode == AppConfig.MODE_PC
                ? reachable(c.pcIp) : reachable(c.hostIp);
        boolean r2 = vm && reachable(c.vmIp);
        if (r1) {
            fail1 = 0;
        } else {
            fail1++;
        }
        if (r2) {
            fail2 = 0;
        } else {
            fail2++;
        }

        // 2. 是否需要全网定位（连续失败 + 节流）
        boolean needScan = (!r1 && fail1 >= FAIL_THRESHOLD)
                || (vm && !r2 && fail2 >= FAIL_THRESHOLD);
        if (needScan) {
            long now = SystemClock.elapsedRealtime();
            if (now - lastFullScan < RESCAN_THROTTLE_MS) {
                needScan = false;
            } else {
                lastFullScan = now;
            }
        }
        final Map<String, String> located = needScan ? fullScan() : null;

        boolean cfgChanged = false;

        // slot1
        int ns1 = state1;
        if (r1) {
            ns1 = ONLINE;
        } else if (fail1 >= FAIL_THRESHOLD) {
            String newIp = located == null ? null
                    : located.get(norm(c.mode == AppConfig.MODE_PC ? c.pcMac : c.hostMac));
            if (newIp != null) {
                if (c.mode == AppConfig.MODE_PC) {
                    if (!newIp.equals(c.pcIp)) {
                        c.pcIp = newIp;
                        cfgChanged = true;
                    }
                } else {
                    if (!newIp.equals(c.hostIp)) {
                        c.hostIp = newIp;
                        cfgChanged = true;
                    }
                }
                ns1 = ONLINE;
                fail1 = 0;
            } else {
                ns1 = OFFLINE;
            }
        }

        // slot2
        int ns2 = state2;
        if (vm) {
            if (r2) {
                ns2 = ONLINE;
            } else if (fail2 >= FAIL_THRESHOLD) {
                String newIp = located == null ? null : located.get(norm(c.vmMac));
                if (newIp != null) {
                    if (!newIp.equals(c.vmIp)) {
                        c.vmIp = newIp;
                        cfgChanged = true;
                    }
                    ns2 = ONLINE;
                    fail2 = 0;
                } else {
                    ns2 = OFFLINE;
                }
            }
        }

        if (cfgChanged) {
            store.save(c);
        }

        final int fs1 = ns1;
        final int fs2 = ns2;
        final boolean changed = cfgChanged;
        main.post(new Runnable() {
            public void run() {
                if (state1 != fs1) {
                    state1 = fs1;
                    if (fs1 != -1) {
                        callback.onState(1, fs1);
                    }
                }
                if (vm && state2 != fs2) {
                    state2 = fs2;
                    if (fs2 != -1) {
                        callback.onState(2, fs2);
                    }
                }
                if (changed) {
                    callback.onConfigChanged();
                }
            }
        });
    }

    /** 同步执行一次全网快速扫描，返回 MAC -> IP（仅可达设备） */
    private Map<String, String> fullScan() {
        if (scanner != null) {
            scanner.cancel();
        }
        scanner = new DeviceScanner(appCtx);
        final Map<String, String> out = new HashMap<String, String>();
        final java.util.concurrent.CountDownLatch latch =
                new java.util.concurrent.CountDownLatch(1);
        scanner.quickScan(new DeviceScanner.QuickCallback() {
            public void onProgress(int done, int total) {
            }

            public void onComplete(Map<String, String> macToIp) {
                if (macToIp != null) {
                    out.putAll(macToIp);
                }
                latch.countDown();
            }

            public void onError(String msg) {
                latch.countDown();
            }
        });
        try {
            latch.await(20, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
        return out;
    }

    private static String norm(String mac) {
        return mac == null ? "" : mac.trim().toLowerCase();
    }
}
