package com.wakepc.woltv.wake;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;

import com.wakepc.woltv.model.AppConfig;
import com.wakepc.woltv.net.DeviceScanner;
import com.wakepc.woltv.net.Pinger;
import com.wakepc.woltv.net.PortProbe;
import com.wakepc.woltv.net.WakeOnLan;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class WakeController {

    public static final int WAIT_TIMEOUT_SEC = 180;
    public static final int HOST_WAIT_SEC = 90;
    public static final int VM_WAIT_SEC = 120;
    public static final int PING_INTERVAL_SEC = 1;
    public static final int LAUNCH_DELAY_SEC = 5;

    public interface Listener {
        void onProgress(String phase, String msg, int progress, int max);

        void onFinished(boolean success, String msg);
    }

    private final Context appCtx;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicBoolean canceled = new AtomicBoolean(false);
    private ExecutorService exec;
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;

    public WakeController(Context context) {
        appCtx = context.getApplicationContext();
    }

    public void cancel() {
        canceled.set(true);
        if (exec != null) {
            exec.shutdownNow();
        }
    }

    public void start(final AppConfig config, final Listener listener) {
        canceled.set(false);
        final String wakeMac = config.wakeMac();

        if (wakeMac == null || wakeMac.isEmpty()) {
            listener.onFinished(false, "唤醒目标缺少 MAC 地址，请重新运行向导");
            return;
        }

        acquireLocks(HOST_WAIT_SEC + VM_WAIT_SEC + LAUNCH_DELAY_SEC + 60);
        exec = Executors.newSingleThreadExecutor();
        exec.execute(new Runnable() {
            public void run() {
                try {
                    // ===== 1. 定位宿主机与远控目标（VM/PC）当前在线状态 =====
                    // 1a. 先快速核对上次绑定的 IP+MAC
                    final String targetMac = config.mode == AppConfig.MODE_VM
                            ? config.vmMac : config.pcMac;
                    String targetIp = config.mode == AppConfig.MODE_VM
                            ? config.vmIp : config.pcIp;
                    boolean targetOnline = DeviceScanner.checkCachedIp(targetIp, targetMac);

                    boolean hostOnline = true;
                    String hostIp = config.hostIp;
                    if (config.mode == AppConfig.MODE_VM) {
                        hostOnline = DeviceScanner.checkCachedIp(config.hostIp, config.hostMac);
                    }

                    // 1b. 任一未确认，做一次全网快速扫描补齐（一次扫描同时定位两者）
                    if (!targetOnline || (config.mode == AppConfig.MODE_VM && !hostOnline)) {
                        java.util.Map<String, String> scan = doQuickScan(listener);
                        if (scan != null) {
                            if (config.mode == AppConfig.MODE_VM) {
                                String hip = scan.get(norm(config.hostMac));
                                if (hip != null) {
                                    hostOnline = true;
                                    hostIp = hip;
                                }
                                String vip = scan.get(norm(config.vmMac));
                                if (vip != null) {
                                    targetOnline = true;
                                    targetIp = vip;
                                }
                            } else {
                                String ip = scan.get(norm(config.pcMac));
                                if (ip != null) {
                                    targetOnline = true;
                                    targetIp = ip;
                                }
                            }
                        }
                    }
                    if (canceled.get()) {
                        postFinished(listener, false, "已取消唤醒");
                        return;
                    }
                    // 等待所需的 IP 必须存在
                    if (!targetOnline && (targetIp == null || targetIp.isEmpty())) {
                        postFinished(listener, false, "未能定位远控目标，请重新运行向导");
                        return;
                    }
                    if (config.mode == AppConfig.MODE_VM && !hostOnline
                            && (hostIp == null || hostIp.isEmpty())) {
                        postFinished(listener, false, "未能定位宿主机，请重新运行向导");
                        return;
                    }

                    // ===== 2. 远控目标（VM/PC）已在线 → 跳过唤醒，直接倒计时 =====
                    if (targetOnline) {
                        postProgress(listener, "LOCATING",
                                config.mode == AppConfig.MODE_VM
                                        ? "虚拟机已在线，跳过唤醒…" : "电脑已在线，跳过唤醒…",
                                1, 1);
                    } else if (config.mode == AppConfig.MODE_VM) {
                        // 3a. 先唤醒并等待【宿主机】上线（此阶段不启动 UU）
                        if (!hostOnline) {
                            postProgress(listener, "SENDING", "正在唤醒宿主机…", 0, HOST_WAIT_SEC);
                            WakeOnLan.send(config.hostMac, config.broadcast, 3);
                            if (canceled.get()) {
                                postFinished(listener, false, "已取消唤醒");
                                return;
                            }
                            if (!waitFor(hostIp, HOST_WAIT_SEC, "正在等待宿主机开机…", listener)) {
                                postFinished(listener, false,
                                        "宿主机未开机。\n请确认宿主机已开启「网络唤醒(WOL)」，且 MAC 正确");
                                return;
                            }
                        }
                        // 3b. 宿主机在线后，连续 ping 通【虚拟机】3 次才确认进入倒计时
                        if (!confirmVm(targetIp, VM_WAIT_SEC, listener)) {
                            postFinished(listener, false,
                                    "虚拟机未启动。\n请在宿主机上启动该虚拟机（或设置随宿主机自启）后重试");
                            return;
                        }
                    } else {
                        // 4. PC：发魔术包并等待【被控电脑】上线
                        postProgress(listener, "SENDING", "正在发送唤醒数据包…", 0, WAIT_TIMEOUT_SEC);
                        WakeOnLan.send(config.pcMac, config.broadcast, 3);
                        if (canceled.get()) {
                            postFinished(listener, false, "已取消唤醒");
                            return;
                        }
                        if (!waitFor(targetIp, WAIT_TIMEOUT_SEC,
                                "已发送魔术包，等待电脑开机…", listener)) {
                            postFinished(listener, false,
                                    "等待超时，电脑未开机。\n请确认电脑已开启「网络唤醒(WOL)」，且 MAC 正确");
                            return;
                        }
                    }

                    // 5. ping 通，等待 5 秒
                    for (int left = LAUNCH_DELAY_SEC; left > 0; left--) {
                        if (canceled.get()) {
                            postFinished(listener, false, "已取消唤醒");
                            return;
                        }
                        postProgress(listener, "ONLINE",
                                "电脑已开机，" + left + " 秒后启动 UU 远控…",
                                LAUNCH_DELAY_SEC - left, LAUNCH_DELAY_SEC);
                        Thread.sleep(1000L);
                    }

                    // 4. 启动 UU 远控 TV 版
                    postProgress(listener, "LAUNCHING", "正在启动 UU 远控 TV 版…",
                            LAUNCH_DELAY_SEC, LAUNCH_DELAY_SEC);
                    if (!UuLauncher.isInstalled(appCtx)) {
                        postFinished(listener, false,
                                "未安装 UU 远控 TV 版（com.netease.uuremote）");
                        return;
                    }
                    boolean ok = UuLauncher.launch(appCtx);
                    if (ok) {
                        postFinished(listener, true, "已启动 UU 远控 TV 版");
                    } else {
                        postFinished(listener, false, "UU 远控启动失败，请手动打开");
                    }
                } catch (Exception e) {
                    postFinished(listener, false, "唤醒流程异常：" + e.getMessage());
                }
            }
        });
    }

    /** 同步执行一次全网快速扫描，返回 MAC -> IP（仅可达设备）；带定位进度 */
    private java.util.Map<String, String> doQuickScan(final Listener listener) {
        final java.util.concurrent.atomic.AtomicReference<java.util.Map<String, String>> ref =
                new java.util.concurrent.atomic.AtomicReference<java.util.Map<String, String>>();
        final java.util.concurrent.CountDownLatch latch =
                new java.util.concurrent.CountDownLatch(1);
        DeviceScanner qs = new DeviceScanner(appCtx);
        qs.quickScan(new DeviceScanner.QuickCallback() {
            public void onProgress(final int done, final int total) {
                postProgress(listener, "LOCATING",
                        "正在定位设备…（" + done + " / " + total + "）", done, total);
            }

            public void onComplete(java.util.Map<String, String> m) {
                ref.set(m);
                latch.countDown();
            }

            public void onError(String msg) {
                latch.countDown();
            }
        });
        try {
            latch.await(20, java.util.concurrent.TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
        return ref.get();
    }

    private static String norm(String mac) {
        return mac == null ? "" : mac.trim().toLowerCase();
    }

    private boolean hostUp(String ip) {
        if (Pinger.pingOnce(ip, 1)) {
            return true;
        }
        if (Pinger.tcpCheck(ip, PortProbe.PORT_SMB, 600)) {
            return true;
        }
        return Pinger.tcpCheck(ip, PortProbe.PORT_RDP, 600);
    }

    /** 持续 ping 指定 IP，可达即返回 true；超时或取消返回 false */
    private boolean waitFor(final String ip, int timeoutSec, final String msgBase,
                            final Listener listener) {
        long start = System.currentTimeMillis();
        int elapsed = 0;
        while (!canceled.get() && elapsed <= timeoutSec) {
            elapsed = (int) ((System.currentTimeMillis() - start) / 1000L);
            postProgress(listener, "WAITING",
                    msgBase + "（" + elapsed + " / " + timeoutSec + " 秒）",
                    elapsed, timeoutSec);
            if (hostUp(ip)) {
                return true;
            }
            for (int i = 0; i < PING_INTERVAL_SEC && !canceled.get(); i++) {
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException e) {
                    return false;
                }
            }
        }
        return false;
    }

    /**
     * 宿主机上线后确认虚拟机：必须连续 ping 通 3 次（每次间隔约 1 秒），进度条显示 1/3..3/3；
     * 任一次失败则重新计数（虚拟机尚未启动或网络未稳定），总时长超过 timeoutSec 仍未达成返回 false。
     */
    private boolean confirmVm(final String ip, int timeoutSec, final Listener listener) {
        final int need = 3;
        long start = System.currentTimeMillis();
        int consec = 0;
        while (!canceled.get()) {
            final int elapsed = (int) ((System.currentTimeMillis() - start) / 1000L);
            if (elapsed > timeoutSec) {
                return false;
            }
            if (hostUp(ip)) {
                consec++;
                postProgress(listener, "VMCHECK",
                        "正在确认虚拟机连接…（" + consec + " / " + need + "）",
                        consec, need);
                if (consec >= need) {
                    return true;
                }
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException e) {
                    return false;
                }
            } else {
                consec = 0;
                postProgress(listener, "WAITING",
                        "宿主机已开机，正在等待虚拟机启动…（" + elapsed
                                + " / " + timeoutSec + " 秒）",
                        elapsed, timeoutSec);
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException e) {
                    return false;
                }
            }
        }
        return false;
    }

    private void postProgress(final Listener l, final String phase, final String msg,
                              final int progress, final int max) {
        main.post(new Runnable() {
            public void run() {
                l.onProgress(phase, msg, progress, max);
            }
        });
    }

    private void postFinished(final Listener l, final boolean success, final String msg) {
        releaseLocks();
        main.post(new Runnable() {
            public void run() {
                l.onFinished(success, msg);
            }
        });
    }

    private void acquireLocks(int seconds) {
        try {
            PowerManager pm = (PowerManager) appCtx.getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "woltv:wakeup");
            wakeLock.acquire(seconds * 1000L);
        } catch (Exception ignored) {
        }
        try {
            WifiManager wm = (WifiManager) appCtx.getSystemService(Context.WIFI_SERVICE);
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "woltv:wifi");
            wifiLock.acquire();
        } catch (Exception ignored) {
        }
    }

    private void releaseLocks() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Exception ignored) {
        }
        try {
            if (wifiLock != null && wifiLock.isHeld()) {
                wifiLock.release();
            }
        } catch (Exception ignored) {
        }
    }
}
