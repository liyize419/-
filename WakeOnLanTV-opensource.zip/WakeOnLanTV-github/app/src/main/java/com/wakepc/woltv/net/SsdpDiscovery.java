package com.wakepc.woltv.net;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.DocumentBuilderFactory;

/**
 * SSDP / UPnP 设备发现：发 M-SEARCH，回收 LOCATION 并并行拉取设备描述 XML，
 * 解析 friendlyName（Windows 开启“网络发现”、Mac、NAS、打印机等会响应）。
 */
public class SsdpDiscovery {

    private static final String MSEARCH =
            "M-SEARCH * HTTP/1.1\r\n"
                    + "HOST: 239.255.255.250:1900\r\n"
                    + "MAN: \"ssdp:discover\"\r\n"
                    + "MX: 2\r\n"
                    + "ST: ssdp:all\r\n"
                    + "\r\n";

    public Map<String, String> discover(long listenMs) {
        final Map<String, String> result = new HashMap<String, String>();
        DatagramSocket socket = null;
        try {
            InetAddress group = InetAddress.getByName("239.255.255.250");
            socket = new DatagramSocket();
            socket.setSoTimeout(1500);
            byte[] req = MSEARCH.getBytes("UTF-8");

            long deadline = System.currentTimeMillis() + listenMs;
            socket.send(new DatagramPacket(req, req.length, group, 1900));

            final Map<String, String> locations = new HashMap<String, String>();
            byte[] buf = new byte[4096];
            boolean second = false;
            while (System.currentTimeMillis() < deadline) {
                if (!second && System.currentTimeMillis() > deadline - listenMs + 1200) {
                    socket.send(new DatagramPacket(req, req.length, group, 1900));
                    second = true;
                }
                try {
                    DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                    socket.receive(pkt);
                    String text = new String(pkt.getData(), 0, pkt.getLength(), "UTF-8");
                    String loc = header(text, "LOCATION");
                    if (loc != null) {
                        String src = pkt.getAddress().getHostAddress();
                        int pct = src.indexOf('%');
                        if (pct >= 0) {
                            src = src.substring(0, pct);
                        }
                        locations.put(src, loc);
                    }
                } catch (java.net.SocketTimeoutException ste) {
                    // continue
                }
            }

            // 并行拉描述 XML（最多 16 个，整体不超过 7 秒）
            ExecutorService pool = Executors.newFixedThreadPool(4, new ThreadFactory() {
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "ssdp-xml");
                    t.setDaemon(true);
                    return t;
                }
            });
            List<Future<?>> tasks = new java.util.ArrayList<Future<?>>();
            Set<String> seen = new HashSet<String>();
            for (final Map.Entry<String, String> e : locations.entrySet()) {
                if (seen.size() >= 16 || !seen.add(e.getValue())) {
                    continue;
                }
                tasks.add(pool.submit(new Callable<Object>() {
                    public Object call() {
                        String name = fetchFriendlyName(e.getValue());
                        if (name != null && !name.isEmpty()) {
                            synchronized (result) {
                                if (!result.containsKey(e.getKey())) {
                                    result.put(e.getKey(), name);
                                }
                            }
                        }
                        return null;
                    }
                }));
            }
            long xmlDeadline = System.currentTimeMillis() + 7000;
            for (Future<?> f : tasks) {
                long left = xmlDeadline - System.currentTimeMillis();
                if (left <= 0) {
                    break;
                }
                try {
                    f.get(left, TimeUnit.MILLISECONDS);
                } catch (Exception ignored) {
                }
            }
            pool.shutdownNow();
        } catch (Exception e) {
            return result;
        } finally {
            if (socket != null) {
                socket.close();
            }
        }
        return result;
    }

    private static String header(String http, String name) {
        for (String line : http.split("\r\n")) {
            int colon = line.indexOf(':');
            if (colon > 0 && line.substring(0, colon).trim().equalsIgnoreCase(name)) {
                return line.substring(colon + 1).trim();
            }
        }
        return null;
    }

    private String fetchFriendlyName(String location) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(location);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(1500);
            conn.setReadTimeout(2500);
            java.io.InputStream is = conn.getInputStream();
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            is.close();
            return parseFriendlyName(bos.toByteArray());
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private static String parseFriendlyName(byte[] data) {
        try {
            Document doc = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder()
                    .parse(new ByteArrayInputStream(data));
            NodeList nl = doc.getElementsByTagName("friendlyName");
            if (nl.getLength() > 0) {
                String v = nl.item(0).getTextContent();
                if (v != null) {
                    v = v.trim();
                    if (!v.isEmpty()) {
                        return v;
                    }
                }
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }
}
