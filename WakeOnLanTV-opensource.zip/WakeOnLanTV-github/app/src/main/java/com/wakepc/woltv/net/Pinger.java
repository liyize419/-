package com.wakepc.woltv.net;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Pinger {
    private static final Pattern TTL = Pattern.compile("ttl=(\\d+)");

    public static boolean tcpCheck(String ip, int port, int timeoutMs) {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(ip, port), timeoutMs);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try {
                s.close();
            } catch (Exception ignored) {
            }
        }
    }

    /** 执行一次系统 ping，返回 TTL；不通返回 -1 */
    public static int pingTtl(String ip, int waitSec) {
        if (waitSec < 1) {
            waitSec = 1;
        }
        Process p = null;
        BufferedReader br = null;
        int ttl = -1;
        try {
            p = Runtime.getRuntime().exec(new String[]{
                    "ping", "-c", "1", "-W", String.valueOf(waitSec), ip});
            br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                Matcher m = TTL.matcher(line);
                if (m.find()) {
                    ttl = Integer.parseInt(m.group(1));
                }
            }
            p.waitFor();
        } catch (Exception e) {
            return -1;
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Exception ignored) {
                }
            }
            if (p != null) {
                p.destroy();
            }
        }
        return ttl;
    }

    public static boolean pingOnce(String ip, int waitSec) {
        return pingTtl(ip, waitSec) >= 0;
    }

    /** 扫描用：ping 不通时，对常见 PC 端口做 TCP 兜底 */
    public static int aliveTtl(String ip) {
        int ttl = pingTtl(ip, 1);
        if (ttl >= 0) {
            return ttl;
        }
        if (tcpCheck(ip, PortProbe.PORT_SMB, 300) || tcpCheck(ip, PortProbe.PORT_RDP, 300)) {
            return 0;
        }
        return -1;
    }

    public static boolean isReachable(String ip, int waitSec) {
        if (pingOnce(ip, waitSec)) {
            return true;
        }
        try {
            return InetAddress.getByName(ip).isReachable(waitSec * 1000);
        } catch (Exception e) {
            return false;
        }
    }
}
