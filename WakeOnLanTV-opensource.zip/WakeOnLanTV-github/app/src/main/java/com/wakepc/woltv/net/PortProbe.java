package com.wakepc.woltv.net;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class PortProbe {
    public static final int PORT_SMB = 445;
    public static final int PORT_RDP = 3389;
    public static final int PORT_SSH = 22;

    public static class Result {
        public boolean smb;
        public boolean rdp;
        public boolean ssh;
        public String reverseName;
    }

    public static boolean tcpOpen(String ip, int port, int timeoutMs) {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(ip, port), timeoutMs);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try {
                s.close();
            } catch (Exception ignored) {
            }
        }
    }

    public static Result probe(final String ip) {
        final Result r = new Result();
        ExecutorService exec = Executors.newFixedThreadPool(4);
        try {
            Future<?> fSmb = exec.submit(new Callable<Boolean>() {
                public Boolean call() {
                    return tcpOpen(ip, PORT_SMB, 500);
                }
            });
            Future<?> fRdp = exec.submit(new Callable<Boolean>() {
                public Boolean call() {
                    return tcpOpen(ip, PORT_RDP, 500);
                }
            });
            Future<?> fSsh = exec.submit(new Callable<Boolean>() {
                public Boolean call() {
                    return tcpOpen(ip, PORT_SSH, 500);
                }
            });
            Future<?> fName = exec.submit(new Callable<String>() {
                public String call() {
                    try {
                        String name = InetAddress.getByName(ip).getCanonicalHostName();
                        if (name != null && !name.equals(ip) && !name.isEmpty()
                                && !name.matches("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")) {
                            return name;
                        }
                    } catch (Exception ignored) {
                    }
                    return null;
                }
            });
            try {
                r.smb = (Boolean) fSmb.get(2, TimeUnit.SECONDS);
            } catch (Exception ignored) {
            }
            try {
                r.rdp = (Boolean) fRdp.get(2, TimeUnit.SECONDS);
            } catch (Exception ignored) {
            }
            try {
                r.ssh = (Boolean) fSsh.get(2, TimeUnit.SECONDS);
            } catch (Exception ignored) {
            }
            try {
                r.reverseName = (String) fName.get(2, TimeUnit.SECONDS);
            } catch (Exception ignored) {
            }
        } finally {
            exec.shutdownNow();
        }
        return r;
    }
}
