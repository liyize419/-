package com.wakepc.woltv;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.wakepc.woltv.data.ConfigStore;
import com.wakepc.woltv.model.AppConfig;
import com.wakepc.woltv.model.Device;
import com.wakepc.woltv.net.DeviceScanner;
import com.wakepc.woltv.net.HomeMonitor;
import com.wakepc.woltv.net.NetInfo;
import com.wakepc.woltv.ui.DeviceAdapter;
import com.wakepc.woltv.wake.WakeController;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    // 页面
    private static final int PAGE_HOME = 0;
    private static final int PAGE_MODE = 1;
    private static final int PAGE_SCANNING = 2;
    private static final int PAGE_PICK = 3;
    private static final int PAGE_CONFIRM = 4;

    // PICK 页用途
    private static final int PICK_PC = 0;
    private static final int PICK_HOST = 1;
    private static final int PICK_VM = 2;

    // 设备在线状态
    private static final int STATUS_CHECKING = 0;
    private static final int STATUS_ONLINE = 1;
    private static final int STATUS_OFFLINE = 2;

    private ConfigStore store;
    private DeviceAdapter pickAdapter;
    private DeviceScanner scanner;
    private HomeMonitor homeMonitor;
    private WakeController wakeController;

    private final List<View> pages = new ArrayList<View>();

    // 向导状态
    private int wizardMode = AppConfig.MODE_PC;
    private int pickPurpose = PICK_PC;
    private List<Device> scanDevices = new ArrayList<Device>();
    private Device selPc;
    private Device selHost;
    private Device selVm;
    private boolean scanAborted;
    private boolean suppressFinishDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        store = new ConfigStore(this);
        pickAdapter = new DeviceAdapter(this);

        pages.add(findViewById(R.id.page_home));
        pages.add(findViewById(R.id.page_wizard_mode));
        pages.add(findViewById(R.id.page_scanning));
        pages.add(findViewById(R.id.page_pick));
        pages.add(findViewById(R.id.page_wizard_confirm));

        bindWizardMode();
        bindScanning();
        bindPick();
        bindConfirm();
        bindHome();
        bindProgress();

        if (store.isConfigured() && store.load() != null) {
            enterHome();
        } else {
            startWizard();
        }
    }

    /** 进入主页：渲染并后台检测在线状态 */
    private void enterHome() {
        showPage(PAGE_HOME);
        renderHome();
        startMonitor();
        findViewById(R.id.home_wake).requestFocus();
    }

    // ================= 页面切换 =================

    private void showPage(int page) {
        for (int i = 0; i < pages.size(); i++) {
            pages.get(i).setVisibility(i == page ? View.VISIBLE : View.GONE);
        }
    }

    private void startWizard() {
        scanDevices = new ArrayList<Device>();
        selPc = null;
        selHost = null;
        selVm = null;
        showPage(PAGE_MODE);
        findViewById(R.id.card_mode_pc).requestFocus();
    }

    // ================= 向导：模式选择 =================

    private void bindWizardMode() {
        findViewById(R.id.card_mode_pc).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wizardMode = AppConfig.MODE_PC;
                beginScan();
            }
        });
        findViewById(R.id.card_mode_vm).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wizardMode = AppConfig.MODE_VM;
                beginScan();
            }
        });
    }

    // ================= 扫描 =================

    private void bindScanning() {
        ((Button) findViewById(R.id.scan_cancel)).setText(R.string.cancel);
        findViewById(R.id.scan_cancel).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                abortScan();
            }
        });
    }

    private void beginScan() {
        scanAborted = false;
        ((TextView) findViewById(R.id.scan_title)).setText(R.string.scan_preparing);
        ((TextView) findViewById(R.id.scan_msg)).setText(R.string.scan_preparing);
        ProgressBar bar = (ProgressBar) findViewById(R.id.scan_progress);
        bar.setIndeterminate(true);
        bar.setProgress(0);
        showPage(PAGE_SCANNING);
        findViewById(R.id.scan_cancel).requestFocus();

        final java.util.concurrent.atomic.AtomicInteger foundCount =
                new java.util.concurrent.atomic.AtomicInteger(0);
        scanner = new DeviceScanner(getApplicationContext());
        final long t0 = System.currentTimeMillis();
        new Thread(new Runnable() {
            public void run() {
                scanner.scan(new DeviceScanner.Callback() {
                    public void onProgress(final int done, final int total) {
                        runOnUiThread(new Runnable() {
                            public void run() {
                                ProgressBar b = (ProgressBar) findViewById(R.id.scan_progress);
                                b.setIndeterminate(false);
                                b.setMax(Math.max(1, total));
                                b.setProgress(done);
                                ((TextView) findViewById(R.id.scan_msg))
                                        .setText("正在扫描局域网：" + done + " / " + total + "…");
                            }
                        });
                    }

                    public void onHostAlive(final String ip) {
                        final int n = foundCount.incrementAndGet();
                        runOnUiThread(new Runnable() {
                            public void run() {
                                ((TextView) findViewById(R.id.scan_title))
                                        .setText("已发现 " + n + " 台电脑设备，正在识别信息…");
                            }
                        });
                    }

                    public void onComplete(final List<Device> devices, List<NetInfo> nets) {
                        postComplete(devices);
                    }

                    public void onError(final String msg) {
                        runOnUiThread(new Runnable() {
                            public void run() {
                                if (scanAborted) {
                                    return;
                                }
                                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                                showPage(PAGE_MODE);
                                findViewById(R.id.card_mode_pc).requestFocus();
                            }
                        });
                    }
                });
            }
        }, "scan-main").start();
    }

    private void postComplete(final List<Device> devices) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (scanAborted) {
                    return;
                }
                scanDevices = devices != null ? devices : new ArrayList<Device>();
                if (wizardMode == AppConfig.MODE_PC) {
                    openPick(PICK_PC);
                } else {
                    openPick(PICK_HOST);
                }
            }
        });
    }

    private void abortScan() {
        scanAborted = true;
        if (scanner != null) {
            scanner.cancel();
        }
        showPage(PAGE_MODE);
        findViewById(R.id.card_mode_pc).requestFocus();
    }

    // ================= 向导：列表选择 =================

    private void bindPick() {
        final ListView list = (ListView) findViewById(R.id.pick_list);
        list.setAdapter(pickAdapter);
        pickAdapter.setOnDevicePickListener(new DeviceAdapter.OnDevicePickListener() {
            public void onDevicePicked(int position) {
                onPicked((Device) pickAdapter.getItem(position));
            }
        });
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Device d = (Device) pickAdapter.getItem(position);
                onPicked(d);
            }
        });
        // 遥控器「确定」键在部分设备上发 ENTER 而非 DPAD_CENTER，统一拦截并确认当前选中项
        list.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP
                        && (keyCode == KeyEvent.KEYCODE_ENTER
                                || keyCode == KeyEvent.KEYCODE_DPAD_CENTER
                                || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) {
                    int pos = list.getSelectedItemPosition();
                    if (pos >= 0 && pos < pickAdapter.getCount()) {
                        list.performItemClick(list.getSelectedView(), pos,
                                pickAdapter.getItemId(pos));
                        return true;
                    }
                }
                return false;
            }
        });
        findViewById(R.id.pick_back).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pickBack();
            }
        });
        findViewById(R.id.pick_rescan).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                beginScan();
            }
        });
    }

    private void openPick(int purpose) {
        pickPurpose = purpose;
        TextView title = (TextView) findViewById(R.id.pick_title);
        if (wizardMode == AppConfig.MODE_PC) {
            title.setText(R.string.pick_pc_title);
        } else if (purpose == PICK_HOST) {
            title.setText(R.string.pick_host_title);
        } else {
            title.setText(R.string.pick_vm_title);
        }
        pickAdapter.setData(scanDevices);
        showPage(PAGE_PICK);
        final ListView list = (ListView) findViewById(R.id.pick_list);
        if (scanDevices.isEmpty()) {
            findViewById(R.id.pick_rescan).requestFocus();
            Toast.makeText(this, R.string.scan_empty, Toast.LENGTH_LONG).show();
        } else {
            list.post(new Runnable() {
                public void run() {
                    list.requestFocus();
                    list.setSelection(0);
                }
            });
        }
    }

    private void onPicked(Device d) {
        if (wizardMode == AppConfig.MODE_PC) {
            selPc = d;
            openConfirm();
            return;
        }
        if (pickPurpose == PICK_HOST) {
            selHost = d;
            openPick(PICK_VM);
        } else {
            selVm = d;
            openConfirm();
        }
    }

    private void pickBack() {
        if (wizardMode == AppConfig.MODE_PC) {
            showPage(PAGE_MODE);
            findViewById(R.id.card_mode_pc).requestFocus();
        } else if (pickPurpose == PICK_HOST) {
            showPage(PAGE_MODE);
            findViewById(R.id.card_mode_pc).requestFocus();
        } else {
            openPick(PICK_HOST);
        }
    }

    // ================= 向导：确认 =================

    private void bindConfirm() {
        findViewById(R.id.confirm_repick).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (wizardMode == AppConfig.MODE_PC) {
                    openPick(PICK_PC);
                } else {
                    openPick(PICK_VM);
                }
            }
        });
        findViewById(R.id.confirm_finish).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finishWizard();
            }
        });
    }

    private void openConfirm() {
        TextView mode = (TextView) findViewById(R.id.confirm_mode);
        TextView l1 = (TextView) findViewById(R.id.confirm_block1_label);
        TextView b1 = (TextView) findViewById(R.id.confirm_block1);
        TextView l2 = (TextView) findViewById(R.id.confirm_block2_label);
        TextView b2 = (TextView) findViewById(R.id.confirm_block2);

        if (wizardMode == AppConfig.MODE_PC) {
            mode.setText(R.string.confirm_mode_pc);
            l1.setText(R.string.home_label_pc);
            b1.setText(deviceBlock(selPc));
            l2.setVisibility(View.GONE);
            b2.setVisibility(View.GONE);
        } else {
            mode.setText(R.string.confirm_mode_vm);
            l1.setText(R.string.home_label_host);
            b1.setText(deviceBlock(selHost));
            l2.setVisibility(View.VISIBLE);
            b2.setVisibility(View.VISIBLE);
            l2.setText(R.string.home_label_vm);
            b2.setText(deviceBlock(selVm));
        }
        showPage(PAGE_CONFIRM);
        findViewById(R.id.confirm_finish).requestFocus();
    }

    private void finishWizard() {
        AppConfig c = new AppConfig();
        c.mode = wizardMode;
        if (wizardMode == AppConfig.MODE_PC) {
            c.pcName = selPc.displayName();
            c.pcIp = selPc.ip;
            c.pcMac = selPc.mac != null ? selPc.mac : "";
            c.broadcast = nz(selPc.broadcast);
        } else {
            c.mode = AppConfig.MODE_VM;
            c.hostName = selHost.displayName();
            c.hostIp = selHost.ip;
            c.hostMac = selHost.mac != null ? selHost.mac : "";
            c.vmName = selVm.displayName();
            c.vmIp = selVm.ip;
            c.vmMac = selVm.mac != null ? selVm.mac : "";
            c.broadcast = nz(selHost.broadcast);
            if (c.broadcast.isEmpty()) {
                c.broadcast = nz(selVm.broadcast);
            }
        }
        store.save(c);
        renderHome();
        showPage(PAGE_HOME);
        startMonitor();
        findViewById(R.id.home_wake).requestFocus();
        Toast.makeText(this, "配置已保存", Toast.LENGTH_SHORT).show();
    }

    // ================= 主页 =================

    private void bindHome() {
        findViewById(R.id.home_wake).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                beginWake();
            }
        });
        findViewById(R.id.home_reset).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                confirmReset();
            }
        });
    }

    private void renderHome() {
        AppConfig c = store.load();
        if (c == null) {
            startWizard();
            return;
        }
        TextView title = (TextView) findViewById(R.id.home_title);
        TextView l1 = (TextView) findViewById(R.id.home_block1_label);
        TextView n1 = (TextView) findViewById(R.id.home_block1);
        TextView l2 = (TextView) findViewById(R.id.home_block2_label);
        TextView n2 = (TextView) findViewById(R.id.home_block2);
        View dot2 = findViewById(R.id.home_dot2);
        View status2 = findViewById(R.id.home_status2);
        View divider = findViewById(R.id.home_divider);

        if (c.mode == AppConfig.MODE_PC) {
            title.setText(R.string.home_title_pc);
            l1.setVisibility(View.VISIBLE);
            l1.setText(R.string.home_label_pc);
            n1.setVisibility(View.VISIBLE);
            n1.setText(devName(c.pcName, "被控电脑"));
            l2.setVisibility(View.GONE);
            n2.setVisibility(View.GONE);
            dot2.setVisibility(View.GONE);
            status2.setVisibility(View.GONE);
            divider.setVisibility(View.GONE);
            setRow(R.id.home_dot1, R.id.home_status1, STATUS_CHECKING);
        } else {
            title.setText(R.string.home_title_vm);
            l1.setVisibility(View.VISIBLE);
            l1.setText(R.string.home_label_host);
            n1.setVisibility(View.VISIBLE);
            n1.setText(devName(c.hostName, "宿主机"));
            l2.setVisibility(View.VISIBLE);
            n2.setVisibility(View.VISIBLE);
            dot2.setVisibility(View.VISIBLE);
            status2.setVisibility(View.VISIBLE);
            divider.setVisibility(View.VISIBLE);
            l2.setText(R.string.home_label_vm);
            n2.setText(devName(c.vmName, "被控虚拟机"));
            setRow(R.id.home_dot1, R.id.home_status1, STATUS_CHECKING);
            setRow(R.id.home_dot2, R.id.home_status2, STATUS_CHECKING);
        }
    }

    /** 更新某个设备行的圆点与状态文字 */
    private void setRow(int dotId, int statusId, int status) {
        ImageView dot = (ImageView) findViewById(dotId);
        TextView st = (TextView) findViewById(statusId);
        if (status == STATUS_ONLINE) {
            dot.setImageResource(R.drawable.dot_online);
            st.setText(R.string.status_online);
            st.setTextColor(getResources().getColor(R.color.online));
        } else if (status == STATUS_OFFLINE) {
            dot.setImageResource(R.drawable.dot_offline);
            st.setText(R.string.status_offline);
            st.setTextColor(getResources().getColor(R.color.offline));
        } else {
            dot.setImageResource(R.drawable.dot_waking);
            st.setText(R.string.status_checking);
            st.setTextColor(getResources().getColor(R.color.waking));
        }
    }

    /** 启动主页实时监控：立即检测一次，之后每 5 秒轮询在线状态，离开主页时停止 */
    private void startMonitor() {
        if (homeMonitor != null) {
            homeMonitor.stop();
        }
        final ProgressBar bar = (ProgressBar) findViewById(R.id.home_scan_bar);
        final TextView hint = (TextView) findViewById(R.id.home_scan_hint);
        bar.setVisibility(View.VISIBLE);
        bar.setIndeterminate(true);
        bar.setProgress(0);
        hint.setVisibility(View.VISIBLE);
        hint.setText("正在检测设备…");

        homeMonitor = new HomeMonitor(this, store, new HomeMonitor.StateCallback() {
            public void onState(final int slot, final int state) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (slot == 1) {
                            setRow(R.id.home_dot1, R.id.home_status1, state);
                        } else {
                            setRow(R.id.home_dot2, R.id.home_status2, state);
                        }
                        // 首次拿到状态后隐藏顶部进度条，之后只更新圆点，避免闪烁
                        bar.setVisibility(View.GONE);
                        hint.setVisibility(View.GONE);
                    }
                });
            }

            public void onConfigChanged() {
                // IP 变化不影响名称/标签，圆点已在 onState 更新，无需整体重绘
            }
        });
        homeMonitor.start();
    }

    @Override
    protected void onDestroy() {
        if (homeMonitor != null) {
            homeMonitor.stop();
        }
        if (wakeController != null) {
            wakeController.cancel();
        }
        super.onDestroy();
    }

    private static boolean containsIp(String s) {
        return s != null && s.matches(".*\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}.*");
    }

    private static String devName(String s, String fallback) {
        if (s == null || s.trim().isEmpty() || containsIp(s)) {
            return fallback;
        }
        return s;
    }

    private static String normMac(String mac) {
        return mac == null ? "" : mac.trim().toLowerCase();
    }

    private void confirmReset() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.home_reset_btn)
                .setMessage("确定清除当前配置并重新运行设置向导吗？")
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.ok, new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        store.reset();
                        startWizard();
                    }
                }).show();
    }

    // ================= 唤醒流程 =================

    private void bindProgress() {
        findViewById(R.id.progress_cancel).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                suppressFinishDialog = true;
                if (wakeController != null) {
                    wakeController.cancel();
                }
                findViewById(R.id.page_progress).setVisibility(View.GONE);
            }
        });
    }

    private void beginWake() {
        final AppConfig c = store.load();
        if (c == null) {
            startWizard();
            return;
        }
        suppressFinishDialog = false;
        TextView pt = (TextView) findViewById(R.id.progress_title);
        pt.setText(R.string.wake_title);
        ProgressBar bar = (ProgressBar) findViewById(R.id.progress_bar);
        bar.setIndeterminate(true);
        ((TextView) findViewById(R.id.progress_msg)).setText(R.string.stage_sending);
        findViewById(R.id.page_progress).setVisibility(View.VISIBLE);
        findViewById(R.id.progress_cancel).requestFocus();

        wakeController = new WakeController(this);
        wakeController.start(c, new WakeController.Listener() {
            public void onProgress(final String phase, final String msg,
                                   final int progress, final int max) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        ProgressBar b = (ProgressBar) findViewById(R.id.progress_bar);
                        ((TextView) findViewById(R.id.progress_msg)).setText(msg);
                        if ("SENDING".equals(phase) || "LAUNCHING".equals(phase)
                                || "CHECKING".equals(phase)) {
                            b.setIndeterminate(true);
                        } else {
                            b.setIndeterminate(false);
                            b.setMax(Math.max(1, max));
                            b.setProgress(progress);
                        }
                    }
                });
            }

            public void onFinished(final boolean success, final String msg) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        findViewById(R.id.page_progress).setVisibility(View.GONE);
                        if (suppressFinishDialog) {
                            return;
                        }
                        if (success) {
                            // UU 已在前台，无需弹窗遮挡
                            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                        } else {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle(R.string.wake_title)
                                    .setMessage(msg)
                                    .setPositiveButton(R.string.ok, null)
                                    .show();
                        }
                    }
                });
            }
        });
    }

    // ================= 返回键 =================

    @Override
    public void onBackPressed() {
        if (findViewById(R.id.page_progress).getVisibility() == View.VISIBLE) {
            suppressFinishDialog = true;
            if (wakeController != null) {
                wakeController.cancel();
            }
            findViewById(R.id.page_progress).setVisibility(View.GONE);
            return;
        }
        int current = -1;
        for (int i = 0; i < pages.size(); i++) {
            if (pages.get(i).getVisibility() == View.VISIBLE) {
                current = i;
            }
        }
        if (current == PAGE_MODE) {
            if (store.isConfigured()) {
                renderHome();
                showPage(PAGE_HOME);
            } else {
                super.onBackPressed();
            }
        } else if (current == PAGE_SCANNING) {
            abortScan();
        } else if (current == PAGE_PICK) {
            pickBack();
        } else if (current == PAGE_CONFIRM) {
            if (wizardMode == AppConfig.MODE_PC) {
                openPick(PICK_PC);
            } else {
                openPick(PICK_VM);
            }
        } else {
            super.onBackPressed();
        }
    }

    // ================= 文本工具 =================

    private String deviceBlock(Device d) {
        StringBuilder sb = new StringBuilder(d.displayName());
        if (d.mac != null && !d.mac.isEmpty()) {
            sb.append('\n').append(d.mac);
        }
        return sb.toString();
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
