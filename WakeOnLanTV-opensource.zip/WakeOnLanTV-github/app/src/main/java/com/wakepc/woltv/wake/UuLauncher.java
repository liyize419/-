package com.wakepc.woltv.wake;

import android.content.Context;
import android.content.Intent;

public class UuLauncher {
    public static final String PACKAGE = "com.netease.uuremote";
    public static final String FALLBACK_ACTIVITY = "com.remote.app.ui.activity.LaunchActivity";

    public static boolean isInstalled(Context context) {
        try {
            context.getPackageManager().getPackageInfo(PACKAGE, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean launch(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(PACKAGE);
        if (intent == null) {
            intent = new Intent(Intent.ACTION_MAIN);
            intent.setClassName(PACKAGE, FALLBACK_ACTIVITY);
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
