package com.wakepc.woltv.model;

import org.json.JSONException;
import org.json.JSONObject;

public class AppConfig {
    public static final int MODE_PC = 0;
    public static final int MODE_VM = 1;

    public int mode = MODE_PC;

    // 单机模式：被控电脑
    public String pcName;
    public String pcIp;
    public String pcMac;

    // 虚拟机模式：宿主机（唤醒目标）+ 虚拟机（远控目标）
    public String hostName;
    public String hostIp;
    public String hostMac;
    public String vmName;
    public String vmIp;
    public String vmMac;

    public String broadcast;

    /** 唤醒魔术包要发往的 MAC */
    public String wakeMac() {
        return mode == MODE_VM ? hostMac : pcMac;
    }

    /** 唤醒目标的 IP（虚拟机模式为宿主机 IP） */
    public String wakeTargetIp() {
        return mode == MODE_VM ? hostIp : pcIp;
    }

    /** 开机检测要持续 ping 的 IP */
    public String targetIp() {
        return mode == MODE_VM ? vmIp : pcIp;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("mode", mode);
        o.put("pcName", nz(pcName));
        o.put("pcIp", nz(pcIp));
        o.put("pcMac", nz(pcMac));
        o.put("hostName", nz(hostName));
        o.put("hostIp", nz(hostIp));
        o.put("hostMac", nz(hostMac));
        o.put("vmName", nz(vmName));
        o.put("vmIp", nz(vmIp));
        o.put("vmMac", nz(vmMac));
        o.put("broadcast", nz(broadcast));
        return o;
    }

    public static AppConfig fromJson(JSONObject o) {
        AppConfig c = new AppConfig();
        c.mode = o.optInt("mode", MODE_PC);
        c.pcName = o.optString("pcName", "");
        c.pcIp = o.optString("pcIp", "");
        c.pcMac = o.optString("pcMac", "");
        c.hostName = o.optString("hostName", "");
        c.hostIp = o.optString("hostIp", "");
        c.hostMac = o.optString("hostMac", "");
        c.vmName = o.optString("vmName", "");
        c.vmIp = o.optString("vmIp", "");
        c.vmMac = o.optString("vmMac", "");
        c.broadcast = o.optString("broadcast", "");
        return c;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
