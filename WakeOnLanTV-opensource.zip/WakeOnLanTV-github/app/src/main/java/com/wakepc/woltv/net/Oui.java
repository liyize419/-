package com.wakepc.woltv.net;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * MAC 地址 OUI 识别：重点标记虚拟网卡（VMware/VirtualBox/Hyper-V/KVM/Xen/Parallels 等），
 * 为虚拟机模式下区分宿主机与虚拟机提供依据。
 */
public class Oui {

    public static class Info {
        public final String vendor;
        public final boolean virtualMachine;

        Info(String vendor, boolean virtualMachine) {
            this.vendor = vendor;
            this.virtualMachine = virtualMachine;
        }
    }

    private static final Map<String, Info> TABLE = new LinkedHashMap<>();

    private static void vm(String prefix, String name) {
        TABLE.put(prefix, new Info(name, true));
    }

    private static void hw(String prefix, String name) {
        TABLE.put(prefix, new Info(name, false));
    }

    static {
        // ---- 虚拟网卡 ----
        vm("00:05:69", "VMware 虚拟机");
        vm("00:0c:29", "VMware 虚拟机");
        vm("00:1c:14", "VMware 虚拟机");
        vm("00:50:56", "VMware 虚拟机");
        vm("08:00:27", "VirtualBox 虚拟机");
        vm("0a:00:27", "VirtualBox 虚拟机");
        vm("00:15:5d", "Hyper-V 虚拟机");
        vm("00:16:3e", "Xen 虚拟机");
        vm("52:54:00", "KVM/QEMU 虚拟机");
        vm("00:1c:42", "Parallels 虚拟机");
        vm("00:a0:98", "Bhyve 虚拟机");
        vm("f0:1c:2d", "Bhyve 虚拟机");

        // ---- 常见物理网卡（仅列少量，未命中时不影响流程）----
        hw("00:1c:bf", "Intel");
        hw("f8:b1:56", "Intel");
        hw("00:1b:21", "Intel");
        hw("00:e0:4c", "Realtek");
        hw("52:54:4c", "Realtek");
        hw("00:14:22", "Dell");
        hw("00:1f:29", "HP");
        hw("00:50:43", "Lenovo");
        hw("ac:22:0b", "ASUS");
        hw("3c:7c:3f", "ASUS");
        hw("00:e0:fc", "Huawei");
        hw("64:09:80", "Xiaomi");
        hw("a4:83:e7", "Apple");
        hw("3c:22:fb", "Apple");
        hw("f0:18:98", "Apple");
    }

    public static Info lookup(String mac) {
        if (mac == null || mac.length() < 8) {
            return null;
        }
        String norm = mac.trim().toLowerCase();
        String prefix = norm.substring(0, 8);
        return TABLE.get(prefix);
    }
}
