package com.wakepc.woltv.net;

import com.wakepc.woltv.model.Device;

public class DeviceClassifier {

    public static boolean isComputer(Device d, MdnsDiscovery.Tags tags) {
        if (d.gateway) {
            return false;
        }
        if (d.smb || d.rdp || d.ssh
                || (d.hostname != null && !d.hostname.isEmpty())
                || d.ttl == 128) {
            return true;
        }
        if (tags != null && tags.computerSignal()) {
            return !tags.excluded();
        }
        return false;
    }
}
