package com.wakepc.woltv.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.wakepc.woltv.R;
import com.wakepc.woltv.model.Device;

import java.util.ArrayList;
import java.util.List;

public class DeviceAdapter extends BaseAdapter {

    public interface OnDevicePickListener {
        void onDevicePicked(int position);
    }

    private final LayoutInflater inflater;
    private final List<Device> data = new ArrayList<Device>();
    private OnDevicePickListener pickListener;

    public DeviceAdapter(Context context) {
        inflater = LayoutInflater.from(context);
    }

    public void setOnDevicePickListener(OnDevicePickListener l) {
        pickListener = l;
    }

    public void setData(List<Device> devices) {
        data.clear();
        if (devices != null) {
            data.addAll(devices);
        }
        notifyDataSetChanged();
    }

    public int getCount() {
        return data.size();
    }

    public Object getItem(int position) {
        return data.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_device, parent, false);
        }
        // 遥控器中键 / 触摸直接由条目自身响应，保证选择可靠
        convertView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (pickListener != null) {
                    pickListener.onDevicePicked(position);
                }
            }
        });
        Device d = data.get(position);
        ImageView dot = (ImageView) convertView.findViewById(R.id.item_dot);
        TextView name = (TextView) convertView.findViewById(R.id.item_name);
        TextView addr = (TextView) convertView.findViewById(R.id.item_addr);
        TextView tags = (TextView) convertView.findViewById(R.id.item_tags);

        dot.setImageResource(d.gateway ? R.drawable.dot_offline
                : (d.virtual ? R.drawable.dot_waking : R.drawable.dot_online));
        name.setText(d.displayName());

        if (d.mac != null && !d.mac.isEmpty()) {
            addr.setText(d.mac);
            addr.setVisibility(View.VISIBLE);
        } else {
            addr.setVisibility(View.GONE);
        }

        StringBuilder t = new StringBuilder();
        if (d.gateway) {
            t.append("网关");
        }
        if (d.virtual) {
            if (t.length() > 0) t.append("  ·  ");
            t.append("虚拟机");
        }
        if (d.smb) {
            if (t.length() > 0) t.append("  ·  ");
            t.append("SMB");
        }
        if (d.rdp) {
            if (t.length() > 0) t.append("  ·  ");
            t.append("远程桌面");
        }
        if (d.ssh) {
            if (t.length() > 0) t.append("  ·  ");
            t.append("SSH");
        }
        tags.setText(t.toString());
        return convertView;
    }
}
