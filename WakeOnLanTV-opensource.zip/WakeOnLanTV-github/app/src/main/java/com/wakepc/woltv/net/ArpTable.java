package com.wakepc.woltv.net;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class ArpTable {

    /** 读取 /proc/net/arp，返回 IP -> 归一化 MAC（仅保留有效、非全零条目） */
    public static Map<String, String> snapshot() {
        Map<String, String> out = new HashMap<>();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("/proc/net/arp"));
            String line;
            boolean header = true;
            while ((line = br.readLine()) != null) {
                if (header) {
                    header = false;
                    continue;
                }
                String[] c = line.trim().split("\\s+");
                if (c.length >= 4) {
                    String ip = c[0];
                    String flags = c[2];
                    String mac = c[3];
                    if ("0x2".equals(flags)
                            && !mac.startsWith("00:00:00:00:00:00")
                            && !mac.startsWith("0:0:0:0:0:0")) {
                        String norm = normalize(mac);
                        if (norm != null) {
                            out.put(ip, norm);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Exception ignored) {
                }
            }
        }
        return out;
    }

    private static String normalize(String mac) {
        String hex = mac.trim().toLowerCase().replaceAll("[^0-9a-f]", "");
        if (hex.length() != 12) {
            return null;
        }
        StringBuilder sb = new StringBuilder(17);
        for (int i = 0; i < 6; i++) {
            if (i > 0) {
                sb.append(':');
            }
            sb.append(hex, i * 2, i * 2 + 2);
        }
        return sb.toString();
    }
}
