# WakeOnLanTV · 电视端局域网唤醒助手

[![Build APK](https://github.com/<your-name>/WakeOnLanTV/actions/workflows/build.yml/badge.svg)](https://github.com/<your-name>/WakeOnLanTV/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Platform: Android TV](https://img.shields.io/badge/Platform-Android%20TV-14b8a6.svg)](https://www.android.com/tv/)

为 **Android TV / 电视盒子** 设计的「一键开机 + 自动远控」工具：在电视上用遥控器唤醒局域网内的电脑（或虚拟机），等待其上线后自动拉起 **UU 远控 TV 版**，全程无需鼠标、无需手动找 App。

> 典型场景：沙发上用电视当显示器，想开电脑打游戏 / 远程办公 —— 打开本应用按一下「唤醒」，电脑开机后自动进入 UU 远控，电视秒变电脑。

---

## ✨ 功能特性

- 📺 **为遥控器而生**：全流程支持方向键 + 确定键，焦点高亮、操作区域足够大；同时兼容触屏 / 鼠标。
- 🧭 **首次启动向导**：引导式配置，两步选机，开箱即用。
- 🖥️ **两种工作模式**
  - **单机模式**：扫描并唤醒局域网内的一台物理电脑。
  - **虚拟机模式**：先唤醒**宿主机**，再确认**被控虚拟机**上线（需连续 ping 通 3 次），避免宿主机刚开机就误判。
- 🔍 **自动设备发现**：多线程并发扫描局域网，自动过滤路由器 / 网关，只保留电脑类设备，并解析**主机名**。
- ⚡ **快速定位**：优先核对上次绑定的 IP，命中即秒开；IP 变化时再全网扫描兜底。
- 🟢 **实时在线状态**：主页每 5 秒轻量探测，状态圆点实时反映在线 / 离线，关机不会误报在线。
- 📶 **标准 Wake-on-LAN**：发送标准魔术包（Magic Packet），无需在电脑上安装任何服务端。
- 🧩 **零第三方依赖**：仅使用 Android Framework 原生 API，APK 体积小、行为透明。

---

## 🔄 工作流程

```
打开应用
   │
   ├─ 首次启动 → 配置向导
   │     ├─ 选择模式（单机 / 虚拟机）
   │     ├─ 扫描局域网 → 选择电脑（虚拟机模式还需选择宿主机）
   │     └─ 确认并保存
   │
   └─ 主页：显示设备名称与实时在线状态
          │
          按「唤醒电脑」
          │
          ├─ 单机模式：发送魔术包 → 持续 ping 被控电脑
          │
          └─ 虚拟机模式：
                1) 宿主机不在线则唤醒并等待宿主机开机
                2) 宿主机上线后连续 ping 虚拟机 3 次（1/3 · 2/3 · 3/3）
          │
          目标 ping 通 → 等待 5 秒 → 自动启动 UU 远控 TV 版
```

若被控目标已在线，则跳过唤醒，直接进入启动 UU 远控的倒计时。

---

## 📷 界面预览

> 可将电视截图放入 `docs/screenshots/` 并在此展示，例如主页、模式选择、设备列表、唤醒进度等。

---

## ✅ 使用前提

1. Android TV / 电视盒子与被控电脑处于**同一局域网（同一网段）**。
2. 被控电脑（虚拟机模式下为**宿主机**）的网卡已在 BIOS / 系统中开启 **Wake-on-LAN（网络唤醒 / WOL）**。
3. 电视上已安装 **UU 远控 TV 版**（包名 `com.netease.uuremote`）；未安装时应用会提示。
4. 虚拟机模式下，建议将被控虚拟机网络设为**桥接模式（与宿主机同一网段）**，并可设置虚拟机随宿主机自启。

---

## ⬇️ 安装

- 前往 [Releases](https://github.com/<your-name>/WakeOnLanTV/releases) 下载最新 APK，通过 U 盘 /  adb 安装到电视：
  ```bash
  adb install WakeOnLanTV.apk
  ```
- 或从本仓库源码自行编译（见下）。

---

## 🛠️ 从源码编译

### 方式一：Android Studio（推荐）

1. Android Studio → `Open` 选择本仓库目录，等待 Gradle 同步。
2. 连接 Android TV（或直接 `Build > Build APK(s)`）。
3. 运行 / 编译，产物位于 `app/build/outputs/apk/debug/`。

### 方式二：命令行

需要 JDK 17。若仓库中已包含 Gradle Wrapper：

```bash
./gradlew assembleDebug        # Windows: gradlew.bat assembleDebug
```

若未包含 Wrapper，可先用本机 Gradle 8.7+ 执行 `gradle wrapper` 生成，或直接：

```bash
gradle assembleDebug
```

编译成功后，调试 APK 路径为：

```
app/build/outputs/apk/debug/app-debug.apk
```

---

## 🔑 应用签名

仓库默认使用 **debug 签名**，便于直接编译安装。若要发布正式版本，请生成自有 keystore（**私钥请勿提交到 Git**，已在 `.gitignore` 中忽略）：

```bash
keytool -genkeypair -v \
  -keystore release.keystore -alias woltv \
  -keyalg RSA -keysize 2048 -validity 10000
```

在仓库根目录创建 `keystore.properties`（同样不会被提交）：

```properties
storeFile=/path/to/release.keystore
storePassword=你的密码
keyAlias=woltv
keyPassword=你的密码
```

并在 `app/build.gradle` 中读取该配置进行签名（参考 Android 官方[配置签名文档](https://developer.android.com/studio/publish/app-signing)）。

---

## 🔐 权限说明

| 权限 | 用途 |
| --- | --- |
| `INTERNET` | 发送魔术包、ping / 端口探测、解析主机名 |
| `ACCESS_NETWORK_STATE` / `ACCESS_WIFI_STATE` | 获取网段、子网掩码、广播地址 |
| `CHANGE_WIFI_MULTICAST_STATE` | 发送局域网广播 / 多播（魔术包、mDNS） |
| `CHANGE_NETWORK_STATE` / `CHANGE_WIFI_STATE` | 唤醒流程中维持网络 |
| `WAKE_LOCK` | 唤醒等待期间保持 CPU 运行，避免电视休眠中断 |

---

## 🧱 项目结构

```
app/src/main/
├── AndroidManifest.xml
├── res/                     # 布局、颜色、尺寸适配、图标、TV Banner
└── java/com/wakepc/woltv/
    ├── MainActivity.java    # 单 Activity 页面状态机（主页 / 向导 / 唤醒浮层）
    ├── data/ConfigStore.java        # 配置持久化
    ├── model/                       # AppConfig、Device 数据模型
    ├── net/
    │   ├── DeviceScanner.java       # 设备扫描（缓存核对 + 全网快速扫描）
    │   ├── HomeMonitor.java         # 主页实时在线状态轮询
    │   ├── WakeOnLan.java           # 魔术包发送
    │   ├── Pinger.java / PortProbe.java   # ICMP ping / TCP 端口探测
    │   ├── ArpTable.java            # ARP 表反查 MAC↔IP
    │   ├── NetBiosName.java         # NetBIOS(137) 主机名解析
    │   ├── MdnsDiscovery.java / SsdpDiscovery.java
    │   ├── DeviceClassifier.java    # 电脑识别 / 网关过滤
    │   ├── Oui.java                 # 虚拟网卡 OUI 识别
    │   └── NetInfo.java             # 网段 / 网关信息
    ├── ui/DeviceAdapter.java        # 设备列表适配器
    └── wake/
        ├── WakeController.java      # 唤醒→等待→确认→启动 全流程控制
        └── UuLauncher.java          # 拉起 UU 远控
```

---

## 🔒 隐私

- 本应用**仅在局域网内通信**，不访问互联网上的任何业务服务器。
- 不收集、不上传任何个人信息或设备信息；配置仅保存在本机。
- 全部源码开放，可自行审计网络行为。

---

## ⚠️ 免责声明

- 本项目是**独立的开源工具**，与网易公司及「UU 远控」无任何关联、合作或背书关系；「UU 远控」及其商标归其权利人所有。本应用仅在本机已安装该 App 的前提下将其拉起。
- Wake-on-LAN 的可用性依赖于硬件、网卡驱动与系统设置，作者不对唤醒结果作保证。
- 请仅在你拥有或已获授权的设备与网络中使用本软件。

---

## 🤝 贡献

欢迎提交 Issue 与 Pull Request，例如：更多远控 App 适配、更准的设备识别、多语言等。

---

## 📄 License

本项目基于 [MIT License](LICENSE) 开源。
