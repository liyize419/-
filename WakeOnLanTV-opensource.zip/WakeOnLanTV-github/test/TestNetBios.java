import java.lang.reflect.Method;

public class TestNetBios {
    public static void main(String[] args) throws Exception {
        byte[] b = new byte[105];
        // header
        b[0] = 0x00; b[1] = 0x2a;       // tx id
        b[2] = (byte) 0x85; b[3] = 0x00;// flags response AA
        b[4] = 0x00; b[5] = 0x01;       // QDCOUNT=1
        b[6] = 0x00; b[7] = 0x01;       // ANCOUNT=1
        // question name: 0x20 + 32*0x41 + 0x00
        b[12] = 0x20;
        for (int i = 0; i < 32; i++) b[13 + i] = 0x41;
        b[45] = 0x00;
        b[46] = 0x00; b[47] = 0x21;     // TYPE NBSTAT
        b[48] = 0x00; b[49] = 0x01;     // CLASS IN
        // answer
        b[50] = (byte) 0xC0; b[51] = 0x0C; // name pointer -> 12
        b[52] = 0x00; b[53] = 0x21;     // type
        b[54] = 0x00; b[55] = 0x01;     // class
        // ttl 56-59 = 0
        b[60] = 0x00; b[61] = 43;       // RDLENGTH
        b[62] = 2;                      // NUM_NAMES
        // name1: DESKTOP-TEST padded to 16, flags 00 00
        String n1 = pad("DESKTOP-TEST");
        byte[] nb1 = n1.getBytes("ISO-8859-1");
        System.arraycopy(nb1, 0, b, 63, 16);
        b[79] = 0x00; b[80] = 0x00;
        // name2: same name, server suffix flags 0x20 0x00
        System.arraycopy(nb1, 0, b, 81, 16);
        b[97] = 0x20; b[98] = 0x00;
        // MAC 99-104

        Class<?> c = Class.forName("com.wakepc.woltv.net.NetBiosName");
        Method m = c.getDeclaredMethod("parseResponse", byte[].class, int.class);
        m.setAccessible(true);
        Object r = m.invoke(null, b, b.length);
        System.out.println("PARSED = [" + r + "]");
        if ("DESKTOP-TEST".equals(r)) {
            System.out.println("TEST_PASS");
        } else {
            System.out.println("TEST_FAIL");
            System.exit(1);
        }
    }

    static String pad(String s) {
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < 16) sb.append(' ');
        return sb.toString();
    }
}
